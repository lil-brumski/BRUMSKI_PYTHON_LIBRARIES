*N/B: Using a command line.*

1. To rebuild this library from scratch, update the *list(APPEND CMAKE_PREFIX_PATH "/data/data/com.termux/files/usr/lib/python3.11/site-packages/pybind11/share/cmake/pybind11")* with your device's equivalent of the location in the list() area.

2. After completing point 1, enter *cd build && make*.

3. Create your own python file. You should be able to move your python file and the .so or .dll file to another directory on your device if you want to.